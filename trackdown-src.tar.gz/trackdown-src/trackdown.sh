#!/bin/bash
exec python /usr/lib/trackdown/main.py
